package project;

import java.util.Scanner;

public class Showroom implements Utility{
	public String NameofShowroom;
	public String AddressofShowroom;
	public String ManagerNameofShowroom;
	public int TotalCarsinShowroom;
	public String TotalEmployeesinShowroom;
	
	
	public void get_details() {
		// TODO Auto-generated constructor stub
		
		   System.out.print("Showroom Name: "+NameofShowroom);		   
		   System.out.print("Showroom Adress: "+AddressofShowroom);		   
		   System.out.print("Manager Name: "+ManagerNameofShowroom);		  
		   System.out.print("Total no of Emp: "+TotalEmployeesinShowroom);	   
		   System.out.print("Total no of Cars: "+TotalCarsinShowroom);
		  
	}
	
	public void set_details() {
		// TODO Auto-generated method stub
		System.out.println("=================================Enter Showroom Details=================================");
		Scanner sc=new Scanner(System.in);
		
		   System.out.print("Showroom Name: ");
		   String showroomName=sc.next();
		   System.out.print("Showroom Adress: ");
		   String showroomAddress=sc.next();
		   System.out.print("Manager Name: ");
		   String managerName=sc.next();
		   System.out.print("Total no of Emp: ");
		   int noOfEmp=sc.nextInt();
		   System.out.print("Total no of Cars: ");
		   int noOfCars=sc.nextInt();

	}
	

}
