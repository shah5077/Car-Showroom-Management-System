package project;

import java.util.Scanner;

import javax.swing.plaf.basic.BasicInternalFrameTitlePane.IconifyAction;

interface Utility{
	public void get_details();
	public void set_details();
}
public class Main {
	
	public static void main_menu() {
		System.out.println("=================================Enter your Choice===============================");
		System.out.println("--------------------------------------------Menu--------------------------------");
        System.out.println("1)AddnewShowroom              2)AddEmployees                    3)AddCars");
        System.out.println("4)GetShowroom                 5)GetEmployees                    6)GetCars");
        System.out.println();
        System.out.println("=================================O for Exit=========================================");

	
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	Scanner sc=new Scanner(System.in);
   
   Showroom sroom[]=new Showroom[5];
   Employees emp[]=new Employees[5];
   Cars car[]=new Cars[5];
   
   int car_counter=0;
   int employees_counter=0;
   int showroom_counter=0;
 
   int choice =100;
   
   
   while (choice!=0) {
        main_menu();
        System.out.print("Enter main Choice: ");
       choice=sc.nextInt();
       while(choice!=9&&choice!=0) {
  switch (choice) {
case 1:
	sroom[showroom_counter]=new Showroom();
	sroom[showroom_counter].set_details();
	showroom_counter++;
	System.out.println();
	System.out.println("1)ADD NEW SHOWROOM");
	System.out.println("9)GO BACK TO MAIN MENU");
	int Inchoice=sc.nextInt();
	if(Inchoice==1) {
		sroom[showroom_counter].set_details();
	}
	else if(Inchoice==9) {
		main_menu();
	}
		
	
	break;

case 2:
	
	emp[employees_counter]=new Employees();
	emp[employees_counter].set_Empdetails();
	employees_counter++;
	System.out.println();
	System.out.println("1)ADD NEW EMPLOYEES");
	System.out.println("9)GO BACK TO MAIN MENU");
	choice=sc.nextInt();
	break;
case 3:
	
	car[car_counter]=new Cars();
	car[car_counter].set_Cardetails();
	car_counter++;
	System.out.println();
	System.out.println("1)ADD NEW CARS");
	System.out.println("9)GO BACK TO MAIN MENU");
	choice=sc.nextInt();	
	break;
case 4:
	for(int i=0;i<showroom_counter;i++) {
		sroom[i].get_details();
	}
	System.out.println();
	System.out.println();
	
	break;
case 5:
	for(int i=0;i<employees_counter;i++) {
		emp[i].get_Empdetails();
	}
	System.out.println();
	System.out.println();
	break;
case 6:
	for(int i=0;i<car_counter;i++) {
   car[i].get_Cardetails();
	}
	break;
case 0:
	
	
	break;

default:System.out.println("Enter Valid Choice: ");
	break;
}
   }  
   }
}
}
