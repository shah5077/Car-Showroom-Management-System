package project;

import java.util.Scanner;

public class Employees extends Showroom{
	public String empName;
	public int empID;
	public int empAge;
	public String empDept;
	
	public void get_Empdetails() {
		// TODO Auto-generated constructor stub
		
		   System.out.print("Emp Name: "+empName);		   
		   System.out.print("Emp ID: "+empID);		   
		   System.out.print("Emp Age: "+empAge);		  
		   System.out.print("Emp Dept: "+empDept);	   
		  
		  
	}
	
	public void set_Empdetails() {
		// TODO Auto-generated method stub
		System.out.println("=================================Enter Employees Details=================================");
		Scanner sc=new Scanner(System.in);
		
		   System.out.print("Emp Name: ");
		   String EmpName=sc.next();
		   System.out.print("Emp Id: ");
		   String EmpID=sc.next();
		   System.out.print("Emp Age: ");
		   String EmpAge=sc.next();
		   System.out.print("Emp Dept: ");
		   String EmpDept=sc.next();
		   

	}
	
	

}
