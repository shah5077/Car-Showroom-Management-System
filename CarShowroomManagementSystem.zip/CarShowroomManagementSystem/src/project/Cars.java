package project;

import java.util.Scanner;

public class Cars extends Showroom{
	public String nameOfCar;
	public double priceOfCar;
	public String fuelType;
	
	public void get_Cardetails() {
		// TODO Auto-generated constructor stub
		
		   System.out.print("Car Name: "+nameOfCar);		   
		   System.out.print("Price of Car: "+priceOfCar);		   
		   System.out.print("Fuel Type: "+fuelType);		  
		     
		  
		  
	}
	
	public void set_Cardetails() {
		// TODO Auto-generated method stub
		System.out.println("=================================Enter Car Details=================================");
		Scanner sc=new Scanner(System.in);
		
		   System.out.print("Car Name: ");
		   String CarName=sc.next();
		   System.out.print("Price of Car: ");
		   double CarPrice=sc.nextDouble();
		   System.out.print("Fuel type: ");
		   String FuelType=sc.next();
		   
		   

	}
	
	
	

}
